window.addEventListener('load', function () {
  var headerHeight = document.getElementById('header').offsetHeight;
  document.getElementById('particles-js').style.height = headerHeight + 'px';
});
