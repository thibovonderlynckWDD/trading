document.addEventListener('DOMContentLoaded', function () {
  const accordionButtons = document.querySelectorAll('.js-accordion');

  accordionButtons.forEach((button) => {
    button.addEventListener('click', function () {
      const panel = this.nextElementSibling;

      // Toggle active class on the button
      this.classList.toggle('active');

      // Toggle max-height to expand/collapse the panel
      if (panel.style.maxHeight) {
        panel.style.maxHeight = null;
      } else {
        panel.style.maxHeight = panel.scrollHeight + 'px';
      }
    });
  });
});
