const benefits = document.querySelectorAll('.c-benefits__lines > div');

const observer = new IntersectionObserver(
  (entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animated');
        observer.unobserve(entry.target);
      }
    });
  },
  {
    rootMargin: '0px 0px -50px 0px', // Adjust this value if needed
  }
);

benefits.forEach((benefit) => {
  observer.observe(benefit);
});
